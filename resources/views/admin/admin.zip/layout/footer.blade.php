<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <p>&copy; nebula it bd</p>
        </div>
    </div>
</div>
